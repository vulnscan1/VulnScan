#!/bin/bash
sudo apt-get update
sudo apt-get upgrade
sudo apt-get install nmap
sudo apt-get install python3
sudo apt-get install wpscan
sudo apt-get install hydra
sudo apt-get install nikto
sudo apt-get install dirb
sudo apt-get install cewl
sudo apt-get install whois
sudo apt-get install dnsrecon
sudo apt autoremove
